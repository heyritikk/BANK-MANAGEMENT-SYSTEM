package com.Servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

@WebServlet("/Trans")
public class transactionServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/bank2";
    private static final String JDBC_USER = "root";
    private static final String JDBC_PASSWORD = "Saurabh@19091";

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String transactionType = request.getParameter("transactionType");
        double amount = Double.parseDouble(request.getParameter("amount"));

        HttpSession session = request.getSession();
        String accountNumber = (String) session.getAttribute("account_number");

        if (accountNumber != null) {
            Connection connection = null;
            try {
                connection = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);
                connection.setAutoCommit(false); // Start transaction

                if ("Delete".equals(transactionType)) {
                    // Delete account
                    String deleteSql = "DELETE FROM customers WHERE account_number = ?";
                    try (PreparedStatement deleteStatement = connection.prepareStatement(deleteSql)) {
                        deleteStatement.setString(1, accountNumber);
                        deleteStatement.executeUpdate();
                        connection.commit(); // Commit transaction

                        // Redirect to a confirmation page or handle appropriately
                        response.sendRedirect("accountDeleted.jsp");
                    }
                } else {
                    // Retrieve the current balance
                    double currentBalance = 0;
                    String getBalanceSql = "SELECT initial_balance FROM customers WHERE account_number = ?";
                    try (PreparedStatement getBalanceStatement = connection.prepareStatement(getBalanceSql)) {
                        getBalanceStatement.setString(1, accountNumber);
                        ResultSet resultSet = getBalanceStatement.executeQuery();
                        if (resultSet.next()) {
                            currentBalance = resultSet.getDouble("initial_balance");
                        }
                    }

                    // Calculate the new balance
                    double newBalance = currentBalance;
                    if ("Deposit".equals(transactionType)) {
                        newBalance += amount;
                    } else if ("Withdrawal".equals(transactionType)) {
                        newBalance -= amount;
                    }

                    // Perform deposit or withdrawal transaction
                    String insertSql = "INSERT INTO transactions (Account_Number, Date, Transaction_Type, Amount, closing_balance) VALUES (?, NOW(), ?, ?, ?)";
                    try (PreparedStatement insertStatement = connection.prepareStatement(insertSql, PreparedStatement.RETURN_GENERATED_KEYS)) {
                        insertStatement.setString(1, accountNumber);
                        insertStatement.setString(2, transactionType);
                        insertStatement.setDouble(3, amount);
                        insertStatement.setDouble(4, newBalance);
                        insertStatement.executeUpdate();

                        // Get the generated key (Transaction_ID) of the inserted transaction
                        ResultSet generatedKeys = insertStatement.getGeneratedKeys();
                        int transactionId = -1;
                        if (generatedKeys.next()) {
                            transactionId = generatedKeys.getInt(1);
                        }

                        // Update the balance in the customers table
                        String updateBalanceSql = "UPDATE customers SET initial_balance = ? WHERE account_number = ?";
                        try (PreparedStatement updateBalanceStatement = connection.prepareStatement(updateBalanceSql)) {
                            updateBalanceStatement.setDouble(1, newBalance);
                            updateBalanceStatement.setString(2, accountNumber);
                            updateBalanceStatement.executeUpdate();
                        }

                        connection.commit(); // Commit transaction

                        // Redirect to a transaction success page or handle appropriately
                        response.sendRedirect("success.jsp");
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
                if (connection != null) {
                    try {
                        connection.rollback(); // Rollback transaction on error
                    } catch (SQLException rollbackEx) {
                        rollbackEx.printStackTrace();
                    }
                }
                response.sendRedirect("transactionFailed.jsp");
            } finally {
                if (connection != null) {
                    try {
                        connection.setAutoCommit(true); // Reset auto-commit to true
                        connection.close();
                    } catch (SQLException closeEx) {
                        closeEx.printStackTrace();
                    }
                }
            }
        } else {
            response.getWriter().println("Account number not found in session. Please log in again.");
        }
    }
}
