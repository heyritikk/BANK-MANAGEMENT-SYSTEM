document.addEventListener('DOMContentLoaded', function () {
    document.getElementById('addCustomerForm').addEventListener('submit', function (event) {
        event.preventDefault();
        // Add your form submission handling logic here
    });
});
